# 
Rainmeter 

<h1 align="center">
  Plainext
</h1>

<h4 align="center">Download Now!</h4>

A *Rainmeter* skin built entirely with only string meters (and other measures). Download rainmeter [here](https://www.rainmeter.net/)

<img src="https://github.com/EnhancedJax/Plainext/blob/main/%40Resources/Images/Splash.png"/>

## Screenshots

<img src="https://github.com/EnhancedJax/Plainext/blob/main/%40Resources/Images/P1.png"/>

<img src="https://github.com/EnhancedJax/Plainext/blob/main/%40Resources/Images/P3.png"/>

<img src="https://github.com/EnhancedJax/Plainext/blob/main/%40Resources/Images/P4.png"/>


# Installation
### Requirements
Rainmeter 4.4 beta or newer: [Download here](https://www.rainmeter.net/)

### Installation Instructions
1. Install rainmeter
1. Download the latest release
1. Open the .rmskin package 
1. Leave the installation settings default, and press install
  
## Contact me
via Discord: **Jax#7000**
